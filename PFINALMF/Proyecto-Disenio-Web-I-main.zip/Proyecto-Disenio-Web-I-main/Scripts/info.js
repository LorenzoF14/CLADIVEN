document.getElementById("general-email").innerText = "ivanapalmav@gmail.com";
document.getElementById("support-email").innerText = "franklinmaradiaga14@gmail.com";
document.getElementById("ivana-phone").innerText = "+504 9810 0936";
document.getElementById("dinora-phone").innerText = "+504 9693-8269";

function openContactForm() {
    // Simular la apertura del formulario de contacto.
    alert("Este es un enlace simulado. En un entorno real, sería redirigido al formulario de contacto.");
}
